//DB connection
const  connection = {
    client: 'mysql',
    connection: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'whether'
    },
};

export default  connection;