

export class UserModel {
    findAll() {
        return {
            'id': 1,
            'username': 'dixon',
            'email': 'dixonsatit@gmail.com'
        };
    }
}