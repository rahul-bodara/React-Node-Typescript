# Fastify Typescript boilerplate

# 1st step : Add DB HostName, UserName and Password in controllers/connection.js file and Create DB in mysql
# 2st step : Remove comment 5 to 8 line in controllers/index.ts run the project and then comment it
# run cmd : nodemon
# API : controllers/index.ts
# DB : controllers/connection.js
# Dependency : Xampp/lampp

